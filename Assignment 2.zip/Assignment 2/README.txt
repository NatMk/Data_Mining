How to run perceptron.py (q1 and q2 directory) and Roc_curve(q3 directory)

1) Using IDE (I used PyCharm)
  Make sure sklearn, numpy, and matplotlib libraries installed. if not installed,follow the procedures listed on 
  https://www.jetbrains.com/help/pycharm/installing-uninstalling-and-upgrading-packages.html

2) From command line
  Once in the q1 or q2 directory,type python perceptron.py or and so on 
  depending on the respective directory. 
  
Note: Once the program starts, you can also put data sets you want to classify from command line in addition to the randomly generated sets. 