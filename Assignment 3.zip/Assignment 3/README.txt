USE PYTHON3.x

For running task.py you need install tensorflow library and matplotlib

for this run this command:
pip install --upgrade tensorflow 
pip install --upgrade matplotlib

If you're installing it on windows/anaconda do the following instead: 

Windows: python -m pip install matplotlib
                : python -m pip install tensorflow

Anaconda: conda install matplotlib
	conda install tensorflow

The next step is running python script as shown below ( From command line). 

python3 Tensorflow_1.py

For Q3, you can simply run the specific code from the folder using the assignment instrcution website: https://www.tensorflow.org/tutorials/