How to run Kmeans.py (q1 directory) and knn.py (q2 directory)

1) Using IDE (I used PyCharm)
  Make sure numpy, Numpy, Scikit and matplotlib libraries installed. if not installed,follow the procedures listed on 
  https://www.jetbrains.com/help/pycharm/installing-uninstalling-and-upgrading-packages.html

2) From command line
  Once in the q1 or q2 directory,type python kmeans.py or python knn.py 
  depending on the respective directory. 